﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 1 - NameList
//	File Name:		Name.cs
//	Description:    File containing a class representing a single name in a list of names. Breaks name into constituent parts.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Monday, February 24, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Text.RegularExpressions;

namespace NameListGUI {

    /// <summary>The Name class represents a single Name object, to be used in the NameList class. It can break a name down into its constituent parts, along with display first or last name first.
    /// It implements the IEquatabl and IComparable interface. </Name></summary>
    /// <seealso cref="System.IEquatable{NameProject.Name}" />
    /// <seealso cref="System.IComparable{NameProject.Name}" />
    public class Name : IEquatable<Name>, IComparable<Name> {
        public int ID { get; set; }
        public String FullName { get; set; }
        public String Last { get; set; }
        public String Suffix { get; set; }
        public String Remainder { get; set; }
        public String[] CommonSuffixes = { "Jr", "Sr", "Jr.", "Sr.", "Md", "Phd", "Jd", "ii", "iii", "iv", "v" };
        public bool SuffixFound;


        /// <summary>Default constructor. Initializes values for Name class.</summary>
        public Name() {
            ID = 1;
            FullName = "John Smith ii";
            Last = "Smith";
            Suffix = "ii";
            Remainder = "John";
        }


        /// <summary>Copy constructor. Copies the values from a different Name object to this one.</summary>
        /// <param name="other">The other.</param>
        public Name(Name other) {
            ID = other.ID;
            FullName = other.FullName;
            Last = other.Last;
            Suffix = other.Suffix;
            Remainder = other.Remainder;
        }


        /// <summary>A parameterized constructor that takes a name and breaks it down into the components of suffix, last name, and remainder of the name.</summary>
        /// <param name="FullName">The full name to be analyzed for its components.</param>
        /// <param name="ID">The individual number associated with the name.</param>
        public Name(String FullName, int ID) {
            Last = String.Empty;
            Remainder = String.Empty;

            SuffixFound = false;

            if (!(FullName.Contains(" ")) || FullName == String.Empty) { // If name is not in proper format, set to default values.
                FullName = "John Smith ii";
                Last = "Smith";
                Suffix = "ii";
                Remainder = "John";
            }

            String fullNameTemp = FullName;

            int delimiterPos = 0;
            List<String> formattedString = new List<string>();
            FullName = FullName.Trim();
            this.FullName = FullName;
            this.ID = ID;

            for (int i = 0; i < CommonSuffixes.Length; i++) {
                if (FullName.ToLower().Contains(", " + CommonSuffixes[i].ToLower())) { // Checks for suffix in name and ignores case.
                    Suffix = CommonSuffixes[i]; // Sets suffix to the one contained in the name.
                    FullName = FullName.Replace(Suffix, "");
                    int SuffixComma = FullName.LastIndexOf(",");
                    FullName = FullName.Remove(SuffixComma); // Removes suffix comma in name.
                    SuffixFound = true; 
                }
            }

            if (SuffixFound) { // If name contains suffix, execute the code.
                delimiterPos = FullName.IndexOf(",");
                if (delimiterPos == -1) { // If comma not found in name, execute the code.
                    delimiterPos = FullName.IndexOf(" ");
                    Last = FullName.Substring(delimiterPos);
                    FullName = FullName.Substring(0, delimiterPos);
                    Remainder = FullName;
                } else { // If comma found in name, execute the code.
                    Last = FullName.Substring(0, delimiterPos);
                    FullName = FullName.Substring(delimiterPos);
                    FullName = FullName.Replace(",", "");
                    FullName = FullName.Replace(" ", "");
                    Remainder = FullName;
                }
            } else { // If name does not contain suffix, execute the code.
                delimiterPos = FullName.IndexOf(",");
                if (delimiterPos == -1) { // If comma not found in name, execute the code.
                    delimiterPos = FullName.IndexOf(" ");
                    Last = FullName.Substring(delimiterPos);
                    FullName = FullName.Substring(0, delimiterPos);
                    Remainder = FullName;
                } else { // If comma found in name, execute.
                    Last = FullName.Substring(0, delimiterPos);
                    FullName = FullName.Substring(delimiterPos);
                    FullName = FullName.Replace(",", "");
                    FullName = FullName.Replace(" ", "");
                    Remainder = FullName;
                }

                FullName = fullNameTemp;
            }

            // Removes unnecessary space at the beginning of the remainder or last name.
            if(Remainder.IndexOf(" ") == 0) {
                Remainder = Remainder.Substring(1);
            }
            if (Last.IndexOf(" ") == 0) {
                Last = Last.Substring(1);
            }
        }

        /// <summary> Returns the name in the form of the first name, followed by the rest of the name.</summary>
        /// <returns></returns>
        public String NameFirstLast() {
            if (SuffixFound) {
                return Remainder + " " + Last + ", " + Suffix;
            }
            return Remainder + " " + Last;
        }

        /// <summary> Returns the name in the form of the last name, followed by the rest of the name.</summary>
        /// <returns></returns>
        public String NameLastFirst() {
            if(SuffixFound) {
                return Last + ", " + Remainder + ", " + Suffix;
            }
            return Last + ", " + Remainder;
        }


        /// <summary>Indicates whether one Name is equal to another Name.</summary>
        /// <param name="other">A Name object that will be compared to this Name object.</param>
        /// <returns>
        ///   <span class="keyword">
        ///     <span class="languageSpecificText">
        ///       <span class="cs">true</span>
        ///       <span class="vb">True</span>
        ///       <span class="cpp">true</span>
        ///     </span>
        ///   </span>
        ///   <span class="nu">
        ///     <span class="keyword">true</span> (<span class="keyword">True</span> in Visual Basic)</span> if the current object is equal to the <paramref name="other" /> parameter; otherwise, <span class="keyword"><span class="languageSpecificText"><span class="cs">false</span><span class="vb">False</span><span class="cpp">false</span></span></span><span class="nu"><span class="keyword">false</span> (<span class="keyword">False</span> in Visual Basic)</span>.
        /// </returns>
        bool IEquatable<Name>.Equals(Name other) {
            return ID == other.ID;
        }

        /// <summary>Override equals method that checks the object is not null before passing into the Equals method that checks for equality between Name objects.</summary>
        /// <param name="obj">The object to compare with the current object.</param>
        /// <returns>
        ///   <span class="keyword">
        ///     <span class="languageSpecificText">
        ///       <span class="cs">true</span>
        ///       <span class="vb">True</span>
        ///       <span class="cpp">true</span>
        ///     </span>
        ///   </span>
        ///   <span class="nu">
        ///     <span class="keyword">true</span> (<span class="keyword">True</span> in Visual Basic)</span> if the specified object  is equal to the current object; otherwise, <span class="keyword"><span class="languageSpecificText"><span class="cs">false</span><span class="vb">False</span><span class="cpp">false</span></span></span><span class="nu"><span class="keyword">false</span> (<span class="keyword">False</span> in Visual Basic)</span>.
        /// </returns>
        public override bool Equals(Object obj) {
            if (obj == null)
                return false;

            Name nameObj = obj as Name; // casts obj to Name
            if (nameObj == null)
                return false;
            else
                return Equals(nameObj); 
        }


        /// <summary>Returns a hash code for the ID of this Name object.</summary>
        /// <returns>A hash code for the ID of this Name object. </returns>
        public override int GetHashCode() {
            return this.ID.GetHashCode();
        }


        /// <summary>Compares two Name objects on a String comparison of a combination of the Last, Rest, and Suffix properties, in that order. .</summary>
        /// <param name="name">A name object to be compared to this Name object.</param>
        /// <returns></returns>
        public int CompareTo(Name name) {
            if (!Last.Equals(name.Last)) {
                return Last.CompareTo(name.Last);
            }
            else if (!Remainder.Equals(name.Remainder)) {
                return Remainder.CompareTo(name.Remainder);
            }
            return (Suffix.CompareTo(name.Suffix));
        }
    }
}