﻿//////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 2 - NameList GUI
//	File Name:		NamePrompt.Designer.cs
//	Description:    The partial class that initializes components and disposes of resources.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Wednesday, March 23, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

namespace NameListGUI {

    /// <summary>Initializes components and disposes of resources.</summary>
    /// <seealso cref="System.Windows.Forms.Form" />
    partial class NamePrompt {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NamePrompt));
            this.nameInput = new System.Windows.Forms.TextBox();
            this.namePromptQuestion = new System.Windows.Forms.Label();
            this.addNameButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // nameInput
            // 
            this.nameInput.Location = new System.Drawing.Point(12, 51);
            this.nameInput.Name = "nameInput";
            this.nameInput.Size = new System.Drawing.Size(537, 26);
            this.nameInput.TabIndex = 0;
            // 
            // namePromptQuestion
            // 
            this.namePromptQuestion.AutoSize = true;
            this.namePromptQuestion.Location = new System.Drawing.Point(12, 19);
            this.namePromptQuestion.Name = "namePromptQuestion";
            this.namePromptQuestion.Size = new System.Drawing.Size(250, 20);
            this.namePromptQuestion.TabIndex = 1;
            this.namePromptQuestion.Text = "What name would you like to add?";
            // 
            // addNameButton
            // 
            this.addNameButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.addNameButton.Location = new System.Drawing.Point(573, 43);
            this.addNameButton.Name = "addNameButton";
            this.addNameButton.Size = new System.Drawing.Size(124, 43);
            this.addNameButton.TabIndex = 2;
            this.addNameButton.Text = "Add";
            this.addNameButton.UseVisualStyleBackColor = true;
            // 
            // NamePrompt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(724, 103);
            this.Controls.Add(this.addNameButton);
            this.Controls.Add(this.namePromptQuestion);
            this.Controls.Add(this.nameInput);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NamePrompt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add a Name";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox nameInput;
        public System.Windows.Forms.Label namePromptQuestion;
        public System.Windows.Forms.Button addNameButton;
    }
}