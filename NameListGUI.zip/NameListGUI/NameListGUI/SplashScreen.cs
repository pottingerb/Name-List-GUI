﻿//////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 2 - NameList GUI
//	File Name:		SplashScreen.cs
//	Description:    The partial class that calls initialize components method and closes the form on click.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Wednesday, March 23, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NameListGUI {


    /// <summary>Initializes components method and closes the form on click.</summary>
    /// <seealso cref="System.Windows.Forms.Form" />
    public partial class SplashScreen : Form {


        /// <summary>Initializes a new instance of the SplashScreen class.</summary>
        public SplashScreen() {
            InitializeComponent();
        }


        /// <summary>Handles the Click event of the splashScreenButton control. It closes the form.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void splashScreenButton_Click(object sender, EventArgs e) {
            this.Close();
        }

    }
}
