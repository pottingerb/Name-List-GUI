﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 2 - NameList GUI
//	File Name:		NamePrompt.cs
//	Description:    Contains partial class that calls initializes components method and closes the form on click event.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Wednesday, March 23, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NameListGUI {

    /// <summary>This class that calls initialized components method and closes the form on button click event.</summary>
    /// <seealso cref="System.Windows.Forms.Form" />
    public partial class NamePrompt : Form {


        /// <summary>Initializes a new instance of the NamePrompt class.</summary>
        public NamePrompt() {
            InitializeComponent();
        }


        /// <summary>Handles the Click event of the addNameButton control. It closes the form.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        public void addNameButton_Click(object sender, EventArgs e) {
            
            this.Close();
        }
    }
}
