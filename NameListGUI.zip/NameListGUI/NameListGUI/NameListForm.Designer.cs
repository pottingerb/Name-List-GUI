﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 2 - NameList GUI
//	File Name:		NameListForm.Designer.cs
//	Description:    Contains partial class that initializes variables and their values and behaviors for components of the form. It also disposes of any resources being used.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Monday, March 21, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;

namespace NameListGUI {


    /// <summary>Initializes variables and their values and behaviors for components of the form. It also disposes of any resources being used.</summary>
    /// <seealso cref="System.Windows.Forms.Form" />
    partial class NameListForm {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NameListForm));
            this.nameListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.switchNameOrderButton = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.suffixLabel = new System.Windows.Forms.Label();
            this.originalNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.suffixTextBox = new System.Windows.Forms.TextBox();
            this.restOfNameLabel = new System.Windows.Forms.Label();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.originalNameLabel = new System.Windows.Forms.Label();
            this.restOfNameTextBox = new System.Windows.Forms.TextBox();
            this.nameListInfoStatusStrip = new System.Windows.Forms.StatusStrip();
            this.nameListIndex = new System.Windows.Forms.ToolStripStatusLabel();
            this.spacingToolTip = new System.Windows.Forms.ToolStripStatusLabel();
            this.formattedDate = new System.Windows.Forms.ToolStripStatusLabel();
            this.dateFormatted = new System.Windows.Forms.ToolStripStatusLabel();
            this.spacingButton = new System.Windows.Forms.ToolStripSplitButton();
            this.dateTimer = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.nameListInfoStatusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // nameListBox
            // 
            this.nameListBox.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.nameListBox.FormattingEnabled = true;
            this.nameListBox.ItemHeight = 20;
            this.nameListBox.Location = new System.Drawing.Point(37, 90);
            this.nameListBox.Name = "nameListBox";
            this.nameListBox.Size = new System.Drawing.Size(302, 204);
            this.nameListBox.TabIndex = 0;
            this.nameListBox.SelectedIndexChanged += new System.EventHandler(this.nameListBox_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(118, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Selected Name";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 33);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(50, 29);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(140, 30);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(140, 30);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(140, 30);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.deleteToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(54, 29);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(146, 30);
            this.addToolStripMenuItem.Text = "Add";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(146, 30);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(61, 29);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(146, 30);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // switchNameOrderButton
            // 
            this.switchNameOrderButton.Location = new System.Drawing.Point(37, 326);
            this.switchNameOrderButton.Name = "switchNameOrderButton";
            this.switchNameOrderButton.Size = new System.Drawing.Size(234, 46);
            this.switchNameOrderButton.TabIndex = 4;
            this.switchNameOrderButton.Text = "Switch to First Name First";
            this.switchNameOrderButton.UseVisualStyleBackColor = true;
            this.switchNameOrderButton.Click += new System.EventHandler(this.switchNameOrderButton_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.suffixLabel);
            this.panel1.Controls.Add(this.originalNameTextBox);
            this.panel1.Controls.Add(this.lastNameLabel);
            this.panel1.Controls.Add(this.suffixTextBox);
            this.panel1.Controls.Add(this.restOfNameLabel);
            this.panel1.Controls.Add(this.lastNameTextBox);
            this.panel1.Controls.Add(this.originalNameLabel);
            this.panel1.Controls.Add(this.restOfNameTextBox);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(391, 90);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(369, 282);
            this.panel1.TabIndex = 5;
            // 
            // suffixLabel
            // 
            this.suffixLabel.AutoSize = true;
            this.suffixLabel.Location = new System.Drawing.Point(3, 216);
            this.suffixLabel.Name = "suffixLabel";
            this.suffixLabel.Size = new System.Drawing.Size(49, 20);
            this.suffixLabel.TabIndex = 10;
            this.suffixLabel.Text = "Suffix";
            // 
            // originalNameTextBox
            // 
            this.originalNameTextBox.Location = new System.Drawing.Point(127, 61);
            this.originalNameTextBox.Name = "originalNameTextBox";
            this.originalNameTextBox.Size = new System.Drawing.Size(229, 26);
            this.originalNameTextBox.TabIndex = 11;
            this.originalNameTextBox.LostFocus += new System.EventHandler(this.originalNameTextBox_LostFocus);
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(3, 166);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(86, 20);
            this.lastNameLabel.TabIndex = 8;
            this.lastNameLabel.Text = "Last Name";
            // 
            // suffixTextBox
            // 
            this.suffixTextBox.Location = new System.Drawing.Point(127, 213);
            this.suffixTextBox.Name = "suffixTextBox";
            this.suffixTextBox.ReadOnly = true;
            this.suffixTextBox.Size = new System.Drawing.Size(229, 26);
            this.suffixTextBox.TabIndex = 9;
            // 
            // restOfNameLabel
            // 
            this.restOfNameLabel.AutoSize = true;
            this.restOfNameLabel.Location = new System.Drawing.Point(3, 114);
            this.restOfNameLabel.Name = "restOfNameLabel";
            this.restOfNameLabel.Size = new System.Drawing.Size(107, 20);
            this.restOfNameLabel.TabIndex = 6;
            this.restOfNameLabel.Text = "Rest of Name";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(127, 163);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.ReadOnly = true;
            this.lastNameTextBox.Size = new System.Drawing.Size(229, 26);
            this.lastNameTextBox.TabIndex = 7;
            // 
            // originalNameLabel
            // 
            this.originalNameLabel.AutoSize = true;
            this.originalNameLabel.Location = new System.Drawing.Point(3, 64);
            this.originalNameLabel.Name = "originalNameLabel";
            this.originalNameLabel.Size = new System.Drawing.Size(108, 20);
            this.originalNameLabel.TabIndex = 4;
            this.originalNameLabel.Text = "Original Name";
            // 
            // restOfNameTextBox
            // 
            this.restOfNameTextBox.Location = new System.Drawing.Point(127, 111);
            this.restOfNameTextBox.Name = "restOfNameTextBox";
            this.restOfNameTextBox.ReadOnly = true;
            this.restOfNameTextBox.Size = new System.Drawing.Size(229, 26);
            this.restOfNameTextBox.TabIndex = 5;
            // 
            // nameListInfoStatusStrip
            // 
            this.nameListInfoStatusStrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.nameListInfoStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nameListIndex,
            this.spacingToolTip,
            this.formattedDate,
            this.dateFormatted,
            this.spacingButton});
            this.nameListInfoStatusStrip.Location = new System.Drawing.Point(0, 420);
            this.nameListInfoStatusStrip.Name = "nameListInfoStatusStrip";
            this.nameListInfoStatusStrip.Size = new System.Drawing.Size(800, 30);
            this.nameListInfoStatusStrip.TabIndex = 6;
            this.nameListInfoStatusStrip.Text = "statusStrip1";
            // 
            // nameListIndex
            // 
            this.nameListIndex.Name = "nameListIndex";
            this.nameListIndex.Size = new System.Drawing.Size(113, 25);
            this.nameListIndex.Text = "Name in List:";
            // 
            // spacingToolTip
            // 
            this.spacingToolTip.Name = "spacingToolTip";
            this.spacingToolTip.Overflow = System.Windows.Forms.ToolStripItemOverflow.Never;
            this.spacingToolTip.Size = new System.Drawing.Size(608, 25);
            this.spacingToolTip.Spring = true;
            this.spacingToolTip.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // formattedDate
            // 
            this.formattedDate.Name = "formattedDate";
            this.formattedDate.Size = new System.Drawing.Size(0, 25);
            // 
            // dateFormatted
            // 
            this.dateFormatted.Name = "dateFormatted";
            this.dateFormatted.Size = new System.Drawing.Size(19, 25);
            this.dateFormatted.Text = "-";
            // 
            // spacingButton
            // 
            this.spacingButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.spacingButton.Image = ((System.Drawing.Image)(resources.GetObject("spacingButton.Image")));
            this.spacingButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.spacingButton.Name = "spacingButton";
            this.spacingButton.Size = new System.Drawing.Size(45, 28);
            this.spacingButton.Text = "toolStripSplitButton1";
            // 
            // dateTimer
            // 
            this.dateTimer.Enabled = true;
            this.dateTimer.Interval = 1000;
            this.dateTimer.Tick += new System.EventHandler(this.dateTimer_Tick);
            // 
            // NameListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.nameListInfoStatusStrip);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.switchNameOrderButton);
            this.Controls.Add(this.nameListBox);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NameListForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Project 2 - Windows Form NameList - version ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NameListForm_FormClosed);
            this.Load += new System.EventHandler(this.NameListForm_Load_1);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.nameListInfoStatusStrip.ResumeLayout(false);
            this.nameListInfoStatusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.Button switchNameOrderButton;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label originalNameLabel;
        private System.Windows.Forms.TextBox restOfNameTextBox;
        private System.Windows.Forms.Label restOfNameLabel;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox suffixTextBox;
        private System.Windows.Forms.Label suffixLabel;
        private System.Windows.Forms.TextBox originalNameTextBox;
        private System.Windows.Forms.StatusStrip nameListInfoStatusStrip;
        private System.Windows.Forms.ToolStripStatusLabel nameListIndex;
        private System.Windows.Forms.ToolStripStatusLabel spacingToolTip;
        private System.Windows.Forms.ToolStripStatusLabel formattedDate;
        public System.Windows.Forms.ListBox nameListBox;
        private System.Windows.Forms.ToolStripStatusLabel dateFormatted;
        private System.Windows.Forms.Timer dateTimer;
        private System.Windows.Forms.ToolStripSplitButton spacingButton;
    }
}

