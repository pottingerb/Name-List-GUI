﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 2 - NameList GUI
//	File Name:		NameListForm.cs
//	Description:    Contains partial class that specifies behavior for user interaction of objects in name list form. 
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Monday, March 21, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace NameListGUI {


    /// <summary>This partial class specifies behavior for objects in the form. It controls elements such as the list box, menu strip, and text boxes.</summary>
    /// <seealso cref="System.Windows.Forms.Form" />
    public partial class NameListForm : Form {

        private int switchNameOrderIndex = 0; // Is set to value of 0 or 1, determines what happens when user clicks on button to switch name order.
        private static int nameListPos = 0; // The list box selected index position to be displayed in the menu strip.
        private Boolean ChangesMade = false; // Determines whether there are unsaved changes.
        private static int nameSelected; // Set to the name that is currently selected by the user.


        /// <summary>Initializes a new instance of the NameListForm class and adds an Event Handler for the loading event.</summary>
        public NameListForm() {
            InitializeComponent();
            Load += new EventHandler(NameListForm_Load);
        }


        /// <summary>Handles the Load event of the NameListForm control.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void NameListForm_Load(object sender, EventArgs e) {
            LoadClock();
        }


        /// <summary>Sets the text of the date tool strip to the appropriate value.</summary>
        private void LoadClock() {
            this.dateFormatted.Text = DateTime.Now.ToLongDateString() + " " + DateTime.Now.ToLongTimeString();
        }


        /// <summary>Calls the LoadClock method.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void dateTimer_Tick(object sender, EventArgs e) {
            LoadClock();
        }


        /// <summary>Handles the LostFocus event of the originalNameTextBox control. It edits the name that user alters in the original name text box.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void originalNameTextBox_LostFocus(object sender, EventArgs e) {
            if (originalNameTextBox.Text != String.Empty && ConsoleMenu.nameList.GetSize() > 0) {
                ConsoleMenu.nameList[nameSelected] = new Name(originalNameTextBox.Text, ConsoleMenu.nameList[nameSelected].ID);
                restOfNameTextBox.Text = ConsoleMenu.nameList[nameSelected].Remainder;
                suffixTextBox.Text = ConsoleMenu.nameList[nameSelected].Suffix;
                lastNameTextBox.Text = ConsoleMenu.nameList[nameSelected].Last;

                nameListBox.Items.Clear();
                for (int i = 0; i < ConsoleMenu.NameIndex; i++) {
                    nameListBox.Items.Add(ConsoleMenu.nameList[i].FullName);
                }

                ChangesMade = true;
            }
        }


        /// <summary>Handles the SelectedIndexChanged event of the nameListBox control. It parses the constituent parts of the name into text boxes and updates the name list position.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void nameListBox_SelectedIndexChanged(object sender, EventArgs e) {
            nameSelected = nameListBox.SelectedIndex;

            originalNameTextBox.Text = ConsoleMenu.nameList[nameSelected].FullName;
            restOfNameTextBox.Text = ConsoleMenu.nameList[nameSelected].Remainder;
            lastNameTextBox.Text = ConsoleMenu.nameList[nameSelected].Last;
            suffixTextBox.Text = ConsoleMenu.nameList[nameSelected].Suffix;

            nameListPos = ConsoleMenu.nameList[nameSelected].ID + 1;
            this.nameListIndex.Text = "Name in List: " + nameListPos;
        }


        /// <summary>Handles the Click event of the switchNameOrderButton control. It switches the ordering of the names as well as updates button name.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void switchNameOrderButton_Click(object sender, System.EventArgs e) {
            if (switchNameOrderIndex == 0) { // Executes if option available is switching to first name first.
                List<String> NameFirstLast = new List<String>();
                NameFirstLast = ConsoleMenu.nameList.NamesFirstLast();

                ConsoleMenu.nameList.NamesFirstLast();
                nameListBox.Items.Clear();
                for (int i = 0; i < ConsoleMenu.NameIndex; i++) {
                    nameListBox.Items.Add(NameFirstLast[i]);
                }

                switchNameOrderButton.Text = "Switch to Last Name First";
                switchNameOrderIndex++;
            } else { // Executes if option available is switching to last name first.
                List<String> NameLastFirst = new List<String>();
                NameLastFirst = ConsoleMenu.nameList.NamesLastFirst();

                ConsoleMenu.nameList.NamesFirstLast();
                nameListBox.Items.Clear();
                for (int i = 0; i < ConsoleMenu.NameIndex; i++) {
                    nameListBox.Items.Add(NameLastFirst[i]);
                }

                switchNameOrderButton.Text = "Switch to First Name First";
                switchNameOrderIndex = 0;
            }

            this.nameListIndex.Text = "Name in List: " + nameSelected;

            nameListBox.SelectedIndex = nameSelected;
        }

        /// <summary>Handles the Click event of the openToolStripMenuItem control. It allows user to select a file and then parses the data into a name list and the list box.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e) {

            nameListBox.Items.Clear();
            ConsoleMenu.SelectTextFile();
            nameListPos = 0;

            for (int i = 0; i < ConsoleMenu.nameList.GetSize(); i++) {
                nameListBox.Items.Add(ConsoleMenu.nameList[i].FullName);
                nameListBox.SelectedIndex = i;
            }

        }


        /// <summary>Handles a Click event on addToolStripMenuItem control. It adds a name to the list of names and list box.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void addToolStripMenuItem_Click(object sender, EventArgs e) {

            NamePrompt np = new NamePrompt();

            np.Text = "Add a Name";
            np.namePromptQuestion.Text = "What name do you want to add?";
            np.addNameButton.Text = "Add";

            if (np.ShowDialog() == DialogResult.OK) {
                string input = np.nameInput.Text;
                ConsoleMenu.AddName(input);

                nameListBox.Items.Add(ConsoleMenu.nameList[ConsoleMenu.NameIndex - 1].FullName); //ConsoleMenu.nameList[ConsoleMenu.nameList.GetSize() - 1].FullName);
                nameListPos = ConsoleMenu.NameIndex - 1;
                this.nameListIndex.Text = "Name in List: " + nameListPos;

                ChangesMade = true;
            }

            this.nameListIndex.Text = "Name in List: " + nameSelected;
            nameListBox.SelectedIndex = nameSelected;
        }


        /// <summary>Handles the Click event of the deleteToolStripMenuItem control. It deletes a name from the name list and list box specified by the user, if that name exists.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e) {
            NamePrompt np = new NamePrompt();
            np.Text = "Remove a Name";
            np.namePromptQuestion.Text = "What name do you want to remove?";
            np.addNameButton.Text = "Remove";

            if (np.ShowDialog() == DialogResult.OK) {
                string input = np.nameInput.Text;

                ConsoleMenu.RemoveName(input);
                nameListBox.Items.Clear();
                for (int i = 0; i < ConsoleMenu.NameIndex; i++) { // Sets new IDs to remove gap of removed name.
                    nameListBox.Items.Add(ConsoleMenu.nameList[i].FullName);
                }
                ChangesMade = true;
            }

            if (nameListBox.Items.Count > 0)
                nameListBox.SelectedIndex = 0;
        }


        /// <summary>Handles the Click event of the saveToolStripMenuItem control. It saves the file and marks that there are no unsaved changes in the program.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void saveToolStripMenuItem_Click(object sender, EventArgs e) {
            ConsoleMenu.SaveFile();
            ChangesMade = false;
        }


        /// <summary>Handles the Click event of the exitToolStripMenuItem control. It calls a command to exit the application.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
            Application.Exit();
        }


        /// <summary>Handles the Click event of the aboutToolStripMenuItem control. It initializes and displays an About Box dialog.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="EventArgs"/> instance containing the event data.</param>
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e) {
            AboutBox1 ab = new AboutBox1();
            ab.ShowDialog();
        }


        /// <summary>Handles the FormClosed event of the NameListForm control. It prompts user to save the file if there are unsaved changes.</summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="FormClosingEventArgs"/> instance containing the event data.</param>
        private void NameListForm_FormClosed(object sender, FormClosingEventArgs e) {
            if (ChangesMade) { // Executes if there are unsaved changes to file.
                MessageBox.Show("You have unsaved changes to this program.");
                ConsoleMenu.SaveFile();
            }
        }

        private void NameListForm_Load_1(object sender, EventArgs e) {

        }
    }


}
