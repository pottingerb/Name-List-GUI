﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 1 - NameList
//	File Name:		Tools.cs
//	Description:    File containing a class with tokenizer method that captures delimiters and words into array. It also displays welcome and goodbye message
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Monday, February 24, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Text.RegularExpressions;

namespace NameListGUI {

    /// <summary>
    /// The class that contains the main method as well as supporting methods. It tokenizes a string using specified delimiters.
    /// </summary>
    public static class Tools {

        public static string UserName;
        public static string UserEmail;
        public static string UserPhoneNumber;

        /// <summary>Tokenizes the specified line.</summary>
        /// <param name="line">The input line to be tokenized.</param>
        /// <param name="delims">The delimiters that will be used in separating the file into the array.</param>
        /// <returns></returns>
        /// 
        public static String[] Tokenize(string line, string delims) {

            char[] arr = delims.ToCharArray();
            int delimiterPos = 0;
            List<String> formattedString = new List<string>();

            while (string.IsNullOrEmpty(line) != true) {
                delimiterPos = line.IndexOfAny(arr);

                if (delimiterPos == 0) {
                    formattedString.Add(line.Substring(0, delimiterPos + 1));
                    line = line.Substring(delimiterPos + 1);
                } else if (delimiterPos == -1) {
                    formattedString.Add(line.Substring(0, line.Length));
                    line = "";
                } else {
                    formattedString.Add(line.Substring(0, delimiterPos));
                    line = line.Substring(delimiterPos);
                }
            }

            for (int i = 0; i < formattedString.Count; i++) {
                formattedString.Remove(" ");
            }

            return formattedString.ToArray();
        }


        /// <summary>Takes the text input to be formatted. It also sets title and initial console colors.</summary>
        /// <returns></returns>
        public static String InputText() {
            Title = "CSCI 2210 - Data Structures: Classwork 1 by Benjamin Pottinger";
            BackgroundColor = ConsoleColor.White;
            ForegroundColor = ConsoleColor.Red;
            Clear();

            WriteLine("Enter text to be processed.");

            ForegroundColor = ConsoleColor.Blue;

            String inputText = Console.ReadLine();
            return inputText;
        }

        /// <summary>Formats and displays the tokens. Formats includes color and spacing. </summary>
        /// <param name="sFormattedString">The formatted string.</param>
        public static void DisplayTokens(String[] sFormattedString) {

            Clear();
            ForegroundColor = ConsoleColor.Red;
            WriteLine(" No.   Token\n" + "----   -----");
            ForegroundColor = ConsoleColor.Blue;

            for (int i = 0; i < sFormattedString.Length; i++) {
                String s = (i + 1).ToString() + ".";
                Write(s.PadLeft(3) + "    ");

                WriteLine(sFormattedString[i]);

                if (i % 9 == 0 && i != 0) {
                    ForegroundColor = ConsoleColor.Red;
                    WriteLine("\nPress any key to continue.");
                    ReadKey();
                    Clear();
                    WriteLine(" No.   Token\n" + "----   -----");

                    ForegroundColor = ConsoleColor.Blue;
                }
            }

            ForegroundColor = ConsoleColor.Red;
            WriteLine("\nPress any key to continue.");
            ReadKey();
        }


        /// <summary>Asks for input from the user representing their name, email, and phone number. Uses regular expressions to validate the user input. Repeats the prompts if invalid the first time.</summary>
        public static void WelcomeMessage() {
            bool resultsInvalidated = true;
            while (resultsInvalidated) {
                Write("Enter your full name: ");
                UserName = Console.ReadLine();
                //Name n = new Name(UserName, 1);
                Write("Enter your email address: ");
                UserEmail = Console.ReadLine();
                Write("Enter your phone number: ");
                UserPhoneNumber = Console.ReadLine();

                bool isEmail = Regex.IsMatch(UserEmail, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
                bool isPhoneNumber = Regex.IsMatch(UserPhoneNumber, @"^[2-9]\d{2}-\d{3}-\d{4}$");

                if (!(isEmail && isPhoneNumber)) {
                    WriteLine("Your email or phone number was in an incorrect format. Please enter the email in the format example@website.com and the phone number in the format XXX-XXX-XXXX.");
                } else {
                    ConsoleMenu.nameList = ConsoleMenu.nameList + (new Name(UserName, ConsoleMenu.NameIndex));
                    ConsoleMenu.NameIndex++;
                    resultsInvalidated = false;
                }
            }

        }
        /// <summary>Displays a goodbye message that retrieves and uses the credentials the user entered in the welcome message. </summary>
        public static void GoodbyeMessage() {
            WriteLine("Thank you " + UserName + " for using our program. We sent a text message receipt to your phone number: " + UserPhoneNumber + ". We also sent the receipt to your email: " + UserEmail);
            ReadKey();
        }
    }
}
