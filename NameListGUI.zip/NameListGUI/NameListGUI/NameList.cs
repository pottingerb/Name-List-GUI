﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 1 - NameList
//	File Name:		NameList.cs
//	Description:    File containing a class representing a list of names. Names are stored in an array.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Monday, February 24, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NameListGUI {


    /// <summary>The class representing a list of names. Has indexer for names List object. Can display sorted names by first name or last name.</summary>
    public class NameList {

        private List<Name> nameList = new List<Name>();

        /// <summary>Gets or sets the Name with the specified identifier.</summary>
        /// <param name="ID">The identifier.</param>
        /// <value>The Name object.</value>
        /// <returns></returns>
        /// <exception cref="IndexOutOfRangeException"></exception>
        public Name this[int ID] {
            get { // Return the specified index here.
                foreach (var obj in nameList) {
                    if (ID == obj.ID) {
                        return obj;
                    }
                }
                  return nameList[ID];
            }
            set { // Set the specified index to value here.
                if(ID < 0 || ID > nameList.Count) {
                    throw new IndexOutOfRangeException($"{ID} is not between 0 and {nameList.Count}, " + $"the value range of subscripts for this list.");
                }
                nameList[ID] = value;
            }
        }


        /// <summary>Implements the operator + for this class.</summary>
        /// <param name="nl">The name list object.</param>
        /// <param name="n">The name to be added to the list.</param>
        /// <returns>The NameList object.</returns>
        public static NameList operator + (NameList nl, Name n) {
            nl.nameList.Add(n);
            return nl;
        }

        /// <summary>Implements the operator - for this class.</summary>
        /// <param name="nl">The name list object.</param>
        /// <param name="n">The name to be removed to the list.</param>
        /// <returns>The NameList object.</returns>
        public static NameList operator - (NameList nl, Name n) {
            nl.nameList.RemoveAt(n.ID);
            return nl;
        }


        /// <summary>Sorts the names in order of first name followed by the rest of the name.</summary>
        /// <returns>The list containing the sorted names.</returns>
        public List<String> NamesFirstLast() {
            List<String> NamesSortedLastFirst = new List<String>();
            for (int i = 0; i < nameList.Count; i++) {
                NamesSortedLastFirst.Add(nameList[i].NameFirstLast());
            }
            return NamesSortedLastFirst;
        }

        /// <summary>Sorts the names in order of last name followed by the rest of the name.</summary>
        /// <returns>The list containing the sorted names.</returns>
        public List<String> NamesLastFirst() {
            List<String> NamesSortedFirstLast = new List<String>();
            for (int i = 0; i < nameList.Count; i++) {
                NamesSortedFirstLast.Add(nameList[i].NameLastFirst());
            }
            return NamesSortedFirstLast;
        }

        /// <summary>Get the size of the name list. </summary>
        /// <returns>The name list. </returns>
        public int GetSize() {
            return nameList.Count;
        }


        /// <summary>Clears the instance of the nameList object.</summary>
        public void Clear() {
            nameList.Clear();
        }
    }

}
