﻿//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//	Project:	    Project 1 - NameList
//	File Name:		Driver.cs
//	Description:    File containing the driver class. This class operates as a menu and manages the program.
//	Course:			CSCI 2210-001 - Data Structures
//	Author:			Benjamin Pottinger, pottingerb@etsu.edu, sophomore year
//	Created:		Monday, February 24, 2020
//	Copyright:		Benjamin Pottinger, 2020
//
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using static System.Console;

namespace NameListGUI {

    /// <summary>The driver class. Presents menu options to the user, manages the entire program.</summary>
    class ConsoleMenu {

        public static NameList nameList = new NameList();
        public static int NameIndex = 0; // Number of names in the program


        /// <summary>Main method. Entry point of the program that only calls methods.</summary>
        /// <param name="args">The arguments.</param>
        //[STAThread]
        //static void Main(String[] args) {
        //    Tools.WelcomeMessage();
        //    MenuOptions();
        //    Tools.GoodbyeMessage();
        //}


        /// <summary>Displays the menu options and executes the correct one until the user exits the program. Can open and save files along with manage the list of names.</summary>
        public static void MenuOptions() {
            bool continueProgram = true;

            while(continueProgram) {
                WriteLine("Enter a number representing an option: ");
                String optionsText = "1) Select a Text File\n2) Display one name in last name format\n3) Display one name in first name format\n4) Display one name in its original format\n5) Display all names in last name format\n6) Display all names in first name format\n7) Display all names in original format\n8) Add a name \n9) Remove a name\n10) Save to Text File\n11) Exit";
                WriteLine(optionsText);
                String option = ReadLine();
                int optionNum = Int16.Parse(option);

                List<String> namesFirst = nameList.NamesFirstLast();
                List<String> namesLast = nameList.NamesLastFirst();

                switch (optionNum) {

                    case 1:
                        SelectTextFile();
                        break;
                    case 2:
                        WriteLine("What name do you want to view in this format? (Type the original full name.) ");
                        String nameLastChoice = ReadLine();

                        for (int i = 0; i < NameIndex; i++) {
                            if (nameList[i].FullName.Equals(nameLastChoice)) {
                                WriteLine(namesLast[i]);
                            }
                        }

                        break;
                    case 3:
                        WriteLine("What name do you want to view in this format? (Type the original full name.) ");
                        String nameFirstChoice = ReadLine();

                        for(int i = 0; i < NameIndex; i++) {
                            if (nameList[i].FullName.Equals(nameFirstChoice)) {
                                WriteLine(namesFirst[i]);
                            }
                        }

                        break;
                    case 4:
                        WriteLine("What name do you want to view in this format? (Type the original full name.) ");
                        String nameFullNameChoice = ReadLine();

                        for(int i = 0; i < NameIndex; i++) {
                            if (nameList[i].FullName.Equals(nameFullNameChoice)) {
                                WriteLine(nameList[i].FullName);
                            }
                        }
                        break;
                    case 5:
                        for (int i = 0; i < nameList.GetSize(); i++) {
                            WriteLine(namesLast[i]);
                        }
                        break;
                    case 6:
                        for (int i = 0; i < nameList.GetSize(); i++) {
                            WriteLine(namesFirst[i]);
                        }
                        break;
                    case 7:
                        for(int i = 0; i < nameList.GetSize(); i++) {
                            WriteLine(nameList[i].FullName);
                        }
                        break;
                    case 8:
                        //AddName();
                        break;
                    case 9:

                        break;
                    case 10:
                        SaveFile();
                        break;
                    case 11:
                        continueProgram = false;
                        WriteLine("Do you want to save the file before you leave? (Y or N)");
                        String fileChoice = ReadLine();
                        if (fileChoice == "Y")
                            SaveFile();
                        break;
                    default:
                        WriteLine("Invalid number. Please try again.");
                        break;
                }

            }
        }


        /// <summary>Adds a name to the name list.</summary>
        public static void AddName(string newName) {
            WriteLine("What name would you like to add?");
            //String newName = ReadLine();

            nameList = nameList + (new Name(newName, NameIndex));
            NameIndex++;
        }


        /// <summary>Removes a name from the name list.</summary>
        /// <param name="removeName">Name to be removed from the list.</param>
        public static void RemoveName(string removeName) {
            WriteLine("What name would you like to remove? (Type the original full name.)");
            //String removeName = ReadLine();

            for (int i = 0; i < NameIndex; i++) {
                if (nameList[i].FullName.Equals(removeName)) { // Checks if name is in position of the name list. 
                    nameList = nameList - (new Name(removeName, nameList[i].ID)); // Removes the name at that position.
                    NameIndex--;
                    for (int j = 0; j < NameIndex; j++) { // Sets new IDs to remove gap of removed name.
                        nameList[j].ID = j;
                    }
                    break;
                }
            }
        }

        /// <summary>Opens a text file and builds a name list from the names it contains, using a newline as the delimiter.</summary>
        public static void SelectTextFile() {
            nameList.Clear();
            NameIndex = 0;

            OpenFileDialog dlg = new OpenFileDialog();
            dlg.InitialDirectory = @"..\..\DataFiles";
            dlg.Title = "Open Names File";
            dlg.Filter = "text files|*.txt;*.text|all files|*.*";

            if(dlg.ShowDialog() == DialogResult.Cancel) {
                MessageBox.Show(null, "No file selected. Application will end.", "No File Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }

            String path = dlg.FileName;
            StreamReader rdr = new StreamReader(dlg.FileName);
            String[] fields;
            while(rdr.Peek() != -1) {
                fields = rdr.ReadLine().Split(Environment.NewLine.ToCharArray());
                nameList = nameList + (new Name(fields[0], NameIndex));
                NameIndex++;
            }
            rdr.Close();
        }


        /// <summary>Saves the list of names created by the user to a text file.</summary>
        public static void SaveFile() {
            
            SaveFileDialog dlg = new SaveFileDialog();

            dlg.InitialDirectory = @"..\..\DataFiles";
            dlg.Title = "Save the Name File";
            dlg.Filter = "text files|*.txt;*.text|all files|*.*";

            if(dlg.ShowDialog() == DialogResult.Cancel) {
                return;
            }
            StreamWriter writer = null;
            try {
                writer = new StreamWriter(new FileStream(dlg.FileName, FileMode.Create, FileAccess.Write));
                for(int i = 0; i < NameIndex; i++) {
                    writer.WriteLine(nameList[i].FullName);
                }
            }
            catch(Exception e) {
                MessageBox.Show(e.GetType() + "\n" + e.Message + "\n" + e.StackTrace, "Output Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
            }
            finally {
                if (writer != null)
                    writer.Close();
            }
            writer.Close();
        }
    }
}
